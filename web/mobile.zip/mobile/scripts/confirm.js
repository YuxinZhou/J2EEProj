/**
 * Created by Y2X on 2016/3/8.
 */

let user = require('../../module/user.js');
user.checkLogin();
window.location.href = './query-student.html';